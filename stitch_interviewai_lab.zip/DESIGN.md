---
name: Luminous Interview
colors:
  surface: '#fbf8ff'
  surface-dim: '#d5d7ff'
  surface-bright: '#fbf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f2ff'
  surface-container: '#edecff'
  surface-container-high: '#e7e6ff'
  surface-container-highest: '#e0e0ff'
  on-surface: '#151838'
  on-surface-variant: '#464552'
  inverse-surface: '#2b2e4f'
  inverse-on-surface: '#f1efff'
  outline: '#777684'
  outline-variant: '#c7c5d4'
  surface-tint: '#5251b9'
  primary: '#5251b9'
  on-primary: '#ffffff'
  primary-container: '#8a8af5'
  on-primary-container: '#1f1987'
  inverse-primary: '#c2c1ff'
  secondary: '#5b5e69'
  on-secondary: '#ffffff'
  secondary-container: '#e0e2ef'
  on-secondary-container: '#61646f'
  tertiary: '#5d5f5f'
  on-tertiary: '#ffffff'
  tertiary-container: '#949595'
  on-tertiary-container: '#2c2e2e'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c2c1ff'
  on-primary-fixed: '#0b006b'
  on-primary-fixed-variant: '#3a38a0'
  secondary-fixed: '#e0e2ef'
  secondary-fixed-dim: '#c3c6d2'
  on-secondary-fixed: '#181b24'
  on-secondary-fixed-variant: '#434751'
  tertiary-fixed: '#e2e2e2'
  tertiary-fixed-dim: '#c6c6c7'
  on-tertiary-fixed: '#1a1c1c'
  on-tertiary-fixed-variant: '#454747'
  background: '#fbf8ff'
  on-background: '#151838'
  surface-variant: '#e0e0ff'
typography:
  headline-xl:
    fontFamily: Hanken Grotesk
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-padding: 24px
  gutter: 16px
  card-gap: 20px
  stack-sm: 12px
  stack-md: 24px
---

## Brand & Style

This design system is built on a "Soft Glassmorphism" aesthetic, prioritizing a sense of calm, clarity, and futuristic intelligence for an AI Interview Bot. The brand personality is encouraging, sophisticated, and transparent. 

The visual style utilizes **Glassmorphism** and **Tactile** elements to create a UI that feels like a physical object made of light and vapor. It moves away from flat design into a world of depth, using blurred backdrops, pearl-white surfaces, and subtle 3D inner shadows (neomorphic hints) to make interactive elements feel "touchable" and responsive. The goal is to reduce interview anxiety through a soft, ethereal atmosphere.

## Colors

The palette is anchored by **Lavender** and **Periwinkle**, providing a modern, tech-forward yet soothing foundation. 

- **Primary:** A vibrant Periwinkle used for active states, key icons, and progress indicators.
- **Secondary/Surface:** A pearl-white translucent base. This is not solid white; it is a high-opacity glass effect that allows the lavender background to subtly bleed through.
- **Background:** A soft lavender gradient that acts as the "environment" for the glass cards.
- **Text/Neutral:** A deep slate-indigo for high legibility against light glass surfaces, avoiding the harshness of pure black.

## Typography

We use **Hanken Grotesk** across all levels for its precision and contemporary feel. It strikes a balance between a technical AI look and a friendly, human-centric geometry. 

Headlines use tighter letter-spacing and heavier weights to feel "anchored" on the translucent surfaces. Body text maintains generous line-heights to ensure readability against dynamic, blurred backgrounds. Labels are capitalized and slightly tracked out to differentiate them from prose.

## Layout & Spacing

The layout follows a **Fluid Grid** model with high internal margins to emphasize the "floating" nature of the glass components.

- **Desktop:** 12-column grid, 24px gutters, max-width 1200px.
- **Mobile:** Single column with 20px side margins.
- **Rhythm:** An 8px base unit is used. However, components should feel spacious—avoid dense information clusters. 
- **The "Wave" Reflow:** On mobile, the transition between the dark "AI" header area and the light "User Content" area should use a curved, organic masking shape to mimic the reference image's fluid divider.

## Elevation & Depth

Depth is the primary communicator of hierarchy in this system. It is achieved through three specific layers:

1.  **The Environment (Level 0):** The base lavender/periwinkle gradient.
2.  **The Glass Layer (Level 1):** Surfaces use a `backdrop-filter: blur(20px)` and a `white/65%` background. A 1px solid white border at 30% opacity creates a "rim light" effect.
3.  **The Interactive Layer (Level 2):** Buttons and active cards use a subtle "extruded" effect. This is achieved via two shadows: a soft dark shadow (bottom-right) and a bright white highlight (top-left), both with very low opacity to maintain the "pearl" look.

Avoid using heavy black shadows; instead, use tinted shadows (Deep Lavender) to keep the UI looking "clean" and "airy."

## Shapes

The shape language is dominated by **generous curves**. Sharp corners are strictly avoided to maintain the soft, approachable brand persona.

- **Main Cards:** Use `rounded-xl` (1.5rem / 24px) to create a friendly, modern container.
- **Buttons & Inputs:** Use `rounded-lg` (1rem / 16px) or full pill-shapes for smaller action items.
- **Icon Backdrops:** Icons should sit inside soft-rounded squares or circles with a slightly more pronounced inner shadow to look "recessed" into the glass.

## Components

### Buttons
Primary buttons are vibrant periwinkle with white text. Secondary buttons use a "frosted glass" look with a subtle 1px white border. On hover, buttons should gain a slight outer "glow" rather than just changing color.

### Cards (The "Pearl" Card)
The core container. Must have `backdrop-filter: blur(25px)` and a subtle `inner-shadow` (white) on the top edge to simulate thickness. Content inside should have ample padding (24px+).

### Input Fields
Inputs are recessed into the surface. Use a slightly darker background shade than the card surface with an `inset shadow` to create a "hollowed out" feel for the text area.

### Chips/Tags
Small, pill-shaped elements with a high-contrast periwinkle background for active states, and a semi-transparent white background for inactive states.

### AI Indicator
A unique component for the AI Interview Bot: a glowing, pulsating orb or a gradient-filled "wave" area that lives in the header, utilizing the same periwinkle/lavender palette with higher saturation.